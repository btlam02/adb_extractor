Below we describe where each of the subdirectories comes from.

* **Main, RTShaderLib**
  These we copied from Ogre. They are in Ogre's source directory, under `Media/`.
* **TestUI**
  This one also comes from Ogre. It's the unzipped version of `Media/packs/SdkTrays.zip` file in Ogre's source directory.
* **Shared**
  This one comes from a submodule that points to the `FatmapSDKSharedAssets` repository.
* **shaders, textures**
  FatmapMobileSDK assets that are not shared with the web version.